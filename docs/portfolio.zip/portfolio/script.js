$(document).ready(function(){
    $framework = $(".framework");
    $container = $(".html");

    // $container.click(function(){
    //     $framework.toggle(200);
    // });
    
});

